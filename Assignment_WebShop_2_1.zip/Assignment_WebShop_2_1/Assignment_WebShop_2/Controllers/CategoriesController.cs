﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Assignment_WebShop_2.Models;
using Assignment_WebShop_2.Services;

namespace Assignment_WebShop_2.Controllers
{
    public class CategoriesController : BaseController
    {

        public CategoriesController(AccountService accountService, WebShopServices service)
            : base(accountService, service)
        {
        }

        public IActionResult AddProductToBasket(int id)
        {
            _service.AddToBasket(id, _accountService.CurrentUserName);
            return RedirectToAction("Index");
        }

        public IActionResult RemoveFromBasket(int id)
        {
            _service.RemoveFromBasket(id, _accountService.CurrentUserName);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Buy()
        {
            // létrehozunk egy foglalást csak az alapadatokkal (apartman, dátumok)
            BasketOrder order = _service.NewOrder();
                                 
            return View("Buy", order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken] // védelem XSRF támadás ellen
        public IActionResult Index(BasketOrder order)
        {
            String userName;

            //if (!_travelService.SaveRent(apartmentId, userName, rent))
            //{
            //    ModelState.AddModelError("", "A foglalás rögzítése sikertelen, kérem próbálja újra!");
            //    return View("Index", rent);
            //}

            //// kiszámoljuk a teljes árat
            //rent.TotalPrice = _travelService.GetPrice(apartmentId, rent);

            //ViewBag.Message = "A foglalását sikeresen rögzítettük!";
            //return View("Result", rent);
            return View("Index");
        }


        // GET: Categories
        public IActionResult Index()
        {
            return View(_service.GetCategories());
        }

        public IActionResult BasketView()
        {
            return View(_service.GetBasket(_accountService.CurrentUserName));
        }

        public IActionResult DisplayImage(int id)
        {
            var item = _service.GetProduct(id);
            return File(item.Image, "image/png");
        }

        public IActionResult DisplayRandomImage(string categoryName)
        {
            var item = _service.GetRandomProduct(categoryName);
            return File(item.Image, "image/png");
        }

        // GET: Categories/Details/5
        public IActionResult Details(int id, string sortOrder = "")
        {
            var list = _service.GetCategoryByID(id);
            if (list == null)
            {
                return NotFound();
            }

            ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["PriceSortParam"] = sortOrder == "price_asc" ? "price_desc" : "price_asc";

            switch (sortOrder)
            {
                case "price_asc":
                    list.Products = list.Products.OrderBy(i => i.Price).ToList();
                    break;
                case "price_desc":
                    list.Products = list.Products.OrderByDescending(i => i.Price).ToList();
                    break;
                case "name_desc":
                    list.Products = list.Products.OrderByDescending(i => i.Manufacturer).ToList();
                    break;
                default:
                    list.Products = list.Products.OrderBy(i => i.Manufacturer).ToList();
                    break;
            }


            return View(list);
        }
    }
}
