﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Assignment_WebShop_2.Migrations
{
    public partial class S0 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
