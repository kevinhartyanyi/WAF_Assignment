﻿using Assignment_WebShop_2.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_WebShop_2.Services
{
    public class WebShopServices
    {
        WebShopContext context;
        Random random;

     

        public WebShopServices(WebShopContext Context)
        {
            context = Context;
            random = new Random();
        }

        public List<BasketElem> GetBasketForUser(string userName)
        {
            var basket = context.Baskets.FirstOrDefault(g => g.UserName == userName);
            return basket.elems.ToList();
        }

        public void RemoveFromBasket(int productId, string userName)
        {
            var basket = context.Baskets.FirstOrDefault(g => g.UserName == userName);

            if(basket.elems.FirstOrDefault(x => x.product.ID == productId).amount > 0)
            {
                basket.elems.FirstOrDefault(x => x.product.ID == productId).amount -= 1;
            }

            context.SaveChanges();
        }                

        public void AddToBasket(int productId, string userName)
        {
            Product p = context.Products
                .FirstOrDefault(i => i.ID == productId);
            
            var basket = context.Baskets.Include(b => b.elems).FirstOrDefault(g => g.UserName == userName);
            System.Diagnostics.Debug.WriteLine("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR " + basket.elems.Count());
            foreach (var item in basket.elems)
            {
                System.Diagnostics.Debug.WriteLine(item.ID + " " + item.product.ID);

            }

            var t = basket.elems.Where(i => i.product.ID == productId);
            if(t.Count() == 0)
            {
                BasketElem elem = new BasketElem();
                elem.product = p;
                elem.amount = 1;
                basket.elems.Add(elem);
                context.Baskets.FirstOrDefault(g => g.UserName == userName).elems.Add(elem);
                System.Diagnostics.Debug.WriteLine("RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR " + context.Baskets.FirstOrDefault(g => g.UserName == userName).elems.Count());
                //context.Baskets.Update(basket);
                //context.Baskets.FirstOrDefault(g => g.UserName == userName).elems.Add(elem);                
                //context.Entry(elem).State = EntityState.Added;
            }
            else
            {
                basket.elems.FirstOrDefault(x => x.product.ID == productId).amount += 1;
                //context.Baskets.Update(basket);
            }

            context.SaveChanges();
        }

        public Basket GetBasket(string userName)
        {
            return context.Baskets.Include(b => b.elems).FirstOrDefault(g => g.UserName == userName);
        }

        public BasketOrder NewOrder()
        {
            var order = new BasketOrder();

            return order;
        }

        public void AddProductToCategory(Product p)
        {
            if (p != null)
            {
                context.Products.Add(p);
            }
            else
            {
                throw new ArgumentNullException(nameof(p), "The item to add must not be null.");
            }

            context.SaveChanges();
        }

        public List<Category> GetCategories(string contain = "")
        {
            return context.Categories
                .Where(x => x.Name.Contains(contain))
                .OrderBy(x => x.Name)
                .ToList();
        }

        public Category GetCategoryByID(Int32 id)
        {
            return context.Categories
                .Include(x => x.Products)
                .Single(x => x.ID == id);
        }

        public Category GetCategoryByName(string categoryName)
        {
            
            return context.Categories
                .Include(x => x.Products)
                .Single(x => x.Name == categoryName);
        }

        public Product GetProduct(int id)
        {
            return context.Products
                .Include(x => x.Category)
                .Single(x => x.ID == id);
        }

        public Product GetRandomProduct(string categoryName)
        {
            var category = GetCategoryByName(categoryName);
            int ind = random.Next(category.Products.Count());
            return category.Products.Skip(ind).First();
        }
    }
}
